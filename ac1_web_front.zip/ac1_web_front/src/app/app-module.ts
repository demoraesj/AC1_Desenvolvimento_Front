import { NgModule, provideBrowserGlobalErrorListeners } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing-module';
import { App } from './app';
import { CalcularMedia } from './calcular-media/calcular-media';
import { ApoliceDeSeguro } from './apolice-de-seguro/apolice-de-seguro';
import { ConversorDeTemperatura } from './conversor-de-temperatura/conversor-de-temperatura';
import { CalculadoraDeImc } from './calculadora-de-imc/calculadora-de-imc';
import { MenuSuperior } from './menu-superior/menu-superior';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  declarations: [
    App,
    CalcularMedia,
    ApoliceDeSeguro,
    ConversorDeTemperatura,
    CalculadoraDeImc,
    MenuSuperior
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    FormsModule
  ],
  providers: [
    provideBrowserGlobalErrorListeners()
  ],
  bootstrap: [App]
})
export class AppModule { }