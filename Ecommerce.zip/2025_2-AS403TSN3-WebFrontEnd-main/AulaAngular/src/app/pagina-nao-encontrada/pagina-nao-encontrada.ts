import { Component } from '@angular/core';

@Component({
  selector: 'app-pagina-nao-encontrada',
  standalone: false,
  templateUrl: './pagina-nao-encontrada.html',
  styleUrl: './pagina-nao-encontrada.css'
})
export class PaginaNaoEncontrada {

}
