import { Component } from '@angular/core';

@Component({
  selector: 'app-apolice-de-seguro',
  standalone: false,
  templateUrl: './apolice-de-seguro.html',
  styleUrl: './apolice-de-seguro.css'
})
export class ApoliceDeSeguro {
  nome: string = '';
  sexo: string = 'masculino'; // Valor padrão
  idade: number = 0;
  valorAutomovel: number = 0;
  valorApolice: number = 0;

  calcularApolice(): void {
    if (this.sexo === 'masculino' && this.idade <= 25) {
      this.valorApolice = this.valorAutomovel * 0.15;
    } else if (this.sexo === 'masculino' && this.idade > 25) {
      this.valorApolice = this.valorAutomovel * 0.10;
    } else if (this.sexo === 'feminino') {
      this.valorApolice = this.valorAutomovel * 0.08;
    } else {
      this.valorApolice = 0;
    }
  }
}
