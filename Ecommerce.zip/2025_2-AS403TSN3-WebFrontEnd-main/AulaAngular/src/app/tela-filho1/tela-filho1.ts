import { Component } from '@angular/core';

@Component({
  selector: 'app-tela-filho1',
  standalone: false,
  templateUrl: './tela-filho1.html',
  styleUrl: './tela-filho1.css'
})
export class TelaFilho1 {

}
