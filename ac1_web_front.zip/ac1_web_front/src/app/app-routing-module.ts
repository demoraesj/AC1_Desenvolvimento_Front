import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CalcularMedia } from './calcular-media/calcular-media';
import { ApoliceDeSeguro } from './apolice-de-seguro/apolice-de-seguro';
import { ConversorDeTemperatura } from './conversor-de-temperatura/conversor-de-temperatura';
import { CalculadoraDeImc } from './calculadora-de-imc/calculadora-de-imc';

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'calcular-media', component: CalcularMedia },
  { path: 'apolice-de-seguro', component: ApoliceDeSeguro },
  { path: 'conversor-de-temperatura', component: ConversorDeTemperatura },
  {path: 'calculadora-de-imc', component: CalculadoraDeImc}
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
