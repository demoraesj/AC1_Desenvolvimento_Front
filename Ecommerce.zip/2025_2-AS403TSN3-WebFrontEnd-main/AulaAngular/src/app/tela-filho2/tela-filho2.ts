import { Component } from '@angular/core';

@Component({
  selector: 'app-tela-filho2',
  standalone: false,
  templateUrl: './tela-filho2.html',
  styleUrl: './tela-filho2.css'
})
export class TelaFilho2 {

}
