import { Component } from '@angular/core';

@Component({
  selector: 'app-conversor-de-temperatura',
  standalone: false,
  templateUrl: './conversor-de-temperatura.html',
  styleUrl: './conversor-de-temperatura.css'
})
export class ConversorDeTemperatura {
  celsius: number = 0;
  fahrenheit: number = 0;
  kelvin: number = 0;

  converterTemperatura(): void {
    this.fahrenheit = (this.celsius * 9 / 5) + 32;
    this.kelvin = this.celsius + 273.15;
  }
}
