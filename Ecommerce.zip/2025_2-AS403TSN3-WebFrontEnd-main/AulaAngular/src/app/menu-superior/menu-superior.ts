import { Component } from '@angular/core';

@Component({
  selector: 'app-menu-superior',
  standalone: false,
  templateUrl: './menu-superior.html',
  styleUrl: './menu-superior.css'
})
export class MenuSuperior {

}
