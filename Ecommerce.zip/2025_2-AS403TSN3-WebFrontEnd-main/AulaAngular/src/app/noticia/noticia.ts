import { Component } from '@angular/core';

@Component({
  selector: 'app-noticia',
  standalone: false,
  templateUrl: './noticia.html',
  styleUrl: './noticia.css'
})
export class Noticia {

}
