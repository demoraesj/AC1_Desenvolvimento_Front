import { Component } from '@angular/core';

@Component({
  selector: 'app-tela-pai',
  standalone: false,
  templateUrl: './tela-pai.html',
  styleUrl: './tela-pai.css'
})
export class TelaPai {

}
