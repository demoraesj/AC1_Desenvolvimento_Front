import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CalculadoraDeImc } from './calculadora-de-imc';

describe('CalculadoraDeImc', () => {
  let component: CalculadoraDeImc;
  let fixture: ComponentFixture<CalculadoraDeImc>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CalculadoraDeImc]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CalculadoraDeImc);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
