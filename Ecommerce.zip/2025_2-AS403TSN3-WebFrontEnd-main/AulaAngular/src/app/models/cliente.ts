export interface Cliente {
    id: number;
    nome: string;
    celular: string;
    cidade: string;
}